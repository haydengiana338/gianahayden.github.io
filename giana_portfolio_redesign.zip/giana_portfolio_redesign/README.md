# Giana Hayden Portfolio Redesign

## What changed
- Full-screen opening cover
- Headshot-focused hero
- Current internship search and upcoming experience displayed immediately
- Short About Me section on the opening screen
- Slide-out dropdown menu
- Sections for past work, certifications, resume, LinkedIn, and contact details

## Add the selected headshot
1. Download or export the selected headshot.
2. Rename it `headshot.jpg`.
3. Place it in the same folder as `index.html`.
4. In `index.html`, remove the inner `<div class="photo-placeholder">...</div>` from the `hero-photo` section.
   The CSS already uses `headshot.jpg` as the background image.

## Before publishing
- Replace the placeholder LinkedIn URL in `index.html` with your real profile URL.
- Review the public phone number and email.
- Upload every file in this folder to the same GitHub repository.
- Replace the existing files; your GitHub Pages URL does not change.
